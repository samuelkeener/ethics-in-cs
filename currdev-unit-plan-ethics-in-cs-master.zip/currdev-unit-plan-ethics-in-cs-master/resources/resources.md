Links
Lesson 02

https://www.fastcompany.com/90582784/the-head-of-the-nrdc-explains-why-office-chit-chat-is-vital-to-an-organizations-success

Lesson 03

https://www.stlouisfed.org/open-vault/2018/november/impact-of-digital-divide

http://www.digitalresponsibility.org/digital-divide-the-technology-gap-between-rich-and-poor

Lesson 04 

https://www.britannica.com/technology/automation/Advantages-and-disadvantages-of-automation

Lesson 05


https://tvweb.com/the-boys-review-bombing/

https://www.inverse.com/gaming/last-of-us-2-review-bombing-metacritic-open

https://www.theguardian.com/us-news/2020/jun/21/trump-tulsa-rally-scheme-k-pop-fans-tiktok-users

https://www.washingtonpost.com/opinions/2020/06/23/darker-side-tiktoks-trump-rally-trolling/

https://en.wikipedia.org/wiki/Review_bomb#Notable_examples

Lesson 06

https://privacy.commonsense.org/evaluation/TikTok---Real-Short-Videos

https://privacy.commonsense.org/privacy-report/instagram

https://diginomica.com/government-should-force-social-media-companies-hand-over-data-research

Lesson 07

https://fileunemployment.org/uncategorized/can-get-fired-facebook-post/

Lesson 08

https://www.cbc.ca/news/technology/the-pros-cons-and-future-of-drm-1.785237

https://www.forbes.com/sites/erikkain/2012/05/17/diablo-iii-fans-should-stay-angry-about-always-online-drm/?sh=6b941b7d1853

Follow up lesson: https://www.gnu.org/philosophy/shouldbefree.en.html




